#ifndef LE_GEN_SCREEN_SAMPLE_H
#define LE_GEN_SCREEN_SAMPLE_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen member widget declarations
extern leWidget* sample_Panel_0;
extern leListWheelWidget* sample_ListWheelWidget_0;
extern leCircleWidget* sample_CircleWidget_0;
extern leCircleWidget* sample_CircleWidget_1;

// event handlers
// !!THESE MUST BE IMPLEMENTED IN THE APPLICATION CODE!!
void event_sample_ListWheelWidget_0_OnSelectionChanged(leListWheelWidget* wgt, int32_t idx);

// screen lifecycle functions
// DO NOT CALL THESE DIRECTLY
leResult screenInit_sample(void); // called when Legato is initialized
leResult screenShow_sample(void); // called when screen is shown
void screenHide_sample(void); // called when screen is hidden
void screenDestroy_sample(void); // called when Legato is destroyed
void screenUpdate_sample(void); // called when Legato is updating

leWidget* screenGetRoot_sample(uint32_t lyrIdx); // gets a root widget for this screen

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LE_GEN_SCREEN_SAMPLE_H
