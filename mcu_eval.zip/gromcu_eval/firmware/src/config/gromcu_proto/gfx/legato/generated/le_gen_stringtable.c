#include "gfx/legato/generated/le_gen_assets.h"

/*****************************************************************************
 * Legato String Table
 * Encoding        ASCII
 * Language Count: 1
 * String Count:   21
 *****************************************************************************/

/*****************************************************************************
 * string table data
 * 
 * this table contains the raw character data for each string
 * 
 * unsigned short - number of indices in the table
 * unsigned short - number of languages in the table
 * 
 * index array (size = number of indices * number of languages
 * 
 * for each index in the array:
 *   unsigned byte - the font ID for the index
 *   unsigned byte[3] - the offset of the string codepoint data in
 *                      the table
 * 
 * string data is found by jumping to the index offset from the start
 * of the table
 * 
 * string data entry:
 *     unsigned short - length of the string in bytes (encoding dependent)
 *     codepoint data - the string data
 ****************************************************************************/

const uint8_t stringTable_data[214] =
{
    0x15,0x00,0x01,0x00,0x00,0x58,0x00,0x00,0x00,0x5E,0x00,0x00,0x00,0x64,0x00,0x00,
    0x00,0x6A,0x00,0x00,0x00,0x70,0x00,0x00,0x00,0x76,0x00,0x00,0x00,0x7C,0x00,0x00,
    0x00,0x82,0x00,0x00,0x00,0x88,0x00,0x00,0x00,0x8E,0x00,0x00,0x00,0x94,0x00,0x00,
    0x00,0x9A,0x00,0x00,0x00,0xA0,0x00,0x00,0x00,0xA6,0x00,0x00,0x00,0xAC,0x00,0x00,
    0x00,0xB2,0x00,0x00,0x00,0xB8,0x00,0x00,0x00,0xBE,0x00,0x00,0x00,0xC4,0x00,0x00,
    0x00,0xCA,0x00,0x00,0x00,0xD0,0x00,0x00,0x04,0x00,0x33,0x30,0x2E,0x30,0x04,0x00,
    0x32,0x39,0x2E,0x38,0x04,0x00,0x33,0x30,0x2E,0x33,0x04,0x00,0x32,0x38,0x2E,0x36,
    0x04,0x00,0x32,0x38,0x2E,0x39,0x04,0x00,0x32,0x38,0x2E,0x37,0x04,0x00,0x32,0x38,
    0x2E,0x31,0x04,0x00,0x32,0x38,0x2E,0x35,0x04,0x00,0x32,0x39,0x2E,0x35,0x04,0x00,
    0x32,0x39,0x2E,0x37,0x04,0x00,0x32,0x39,0x2E,0x30,0x04,0x00,0x33,0x30,0x2E,0x31,
    0x04,0x00,0x32,0x39,0x2E,0x34,0x04,0x00,0x32,0x39,0x2E,0x36,0x04,0x00,0x32,0x39,
    0x2E,0x39,0x04,0x00,0x33,0x30,0x2E,0x34,0x04,0x00,0x32,0x38,0x2E,0x38,0x04,0x00,
    0x33,0x30,0x2E,0x32,0x04,0x00,0x32,0x39,0x2E,0x33,0x04,0x00,0x33,0x30,0x2E,0x35,
    0x04,0x00,0x32,0x39,0x2E,0x32,
};

/* font asset pointer list */
leFont* fontList[1] =
{
    (leFont*)&HelveticaNeueLTStdRoman,
};

const leStringTable stringTable =
{
    {
        LE_STREAM_LOCATION_ID_INTERNAL, // data location id
        (void*)stringTable_data, // data address pointer
        214, // data size
    },
    (void*)stringTable_data, // string table data
    fontList, // font lookup table
    LE_STRING_ENCODING_ASCII // encoding standard
};


// string list
leTableString string_s30_0;
leTableString string_s29_8;
leTableString string_s30_3;
leTableString string_s28_6;
leTableString string_s28_9;
leTableString string_s28_7;
leTableString string_s29_1;
leTableString string_s28_5;
leTableString string_s29_5;
leTableString string_s29_7;
leTableString string_s29_0;
leTableString string_s30_1;
leTableString string_s29_4;
leTableString string_s29_6;
leTableString string_s29_9;
leTableString string_s30_4;
leTableString string_s28_8;
leTableString string_s30_2;
leTableString string_s29_3;
leTableString string_s30_5;
leTableString string_s29_2;

void initializeStrings(void)
{
    leTableString_Constructor(&string_s30_0, stringID_s30_0);
    leTableString_Constructor(&string_s29_8, stringID_s29_8);
    leTableString_Constructor(&string_s30_3, stringID_s30_3);
    leTableString_Constructor(&string_s28_6, stringID_s28_6);
    leTableString_Constructor(&string_s28_9, stringID_s28_9);
    leTableString_Constructor(&string_s28_7, stringID_s28_7);
    leTableString_Constructor(&string_s29_1, stringID_s29_1);
    leTableString_Constructor(&string_s28_5, stringID_s28_5);
    leTableString_Constructor(&string_s29_5, stringID_s29_5);
    leTableString_Constructor(&string_s29_7, stringID_s29_7);
    leTableString_Constructor(&string_s29_0, stringID_s29_0);
    leTableString_Constructor(&string_s30_1, stringID_s30_1);
    leTableString_Constructor(&string_s29_4, stringID_s29_4);
    leTableString_Constructor(&string_s29_6, stringID_s29_6);
    leTableString_Constructor(&string_s29_9, stringID_s29_9);
    leTableString_Constructor(&string_s30_4, stringID_s30_4);
    leTableString_Constructor(&string_s28_8, stringID_s28_8);
    leTableString_Constructor(&string_s30_2, stringID_s30_2);
    leTableString_Constructor(&string_s29_3, stringID_s29_3);
    leTableString_Constructor(&string_s30_5, stringID_s30_5);
    leTableString_Constructor(&string_s29_2, stringID_s29_2);
}
