/*******************************************************************************
 Module for Microchip Legato Graphics Library

  Company:
    Microchip Technology Inc.

  File Name:
    le_gen_assets.h

  Summary:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.


  Description:
    Header file containing a list of asset specifications for use with the
    Legato Graphics Stack.

*******************************************************************************/


// DOM-IGNORE-BEGIN
/*******************************************************************************
* Copyright (C)  Microchip Technology Inc. and its subsidiaries.
*
* Subject to your compliance with these terms, you may use Microchip software
* and any derivatives exclusively with Microchip products. It is your
* responsibility to comply with third party license terms applicable to your
* use of third party software (including open source software) that may
* accompany Microchip software.
*
* THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
* EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
* WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
* PARTICULAR PURPOSE.
*
* IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
* INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
* WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
* BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
* FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
* ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
* THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
*******************************************************************************/

// DOM-IGNORE-END

#ifndef LE_GEN_ASSETS_H
#define LE_GEN_ASSETS_H

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

#include "gfx/legato/legato.h"

extern const lePalette leGlobalPalette;

/*****************************************************************************
 * Legato Graphics Image Assets
 *****************************************************************************/
/*********************************
 * Legato Image Asset
 * Name:   Image0
 * Size:   240x236 pixels
 * Type:   RGB Data
 * Format: RGB_565
 ***********************************/
extern leImage Image0;

/*****************************************************************************
 * Legato Graphics Font Assets
 *****************************************************************************/
/*********************************
 * Legato Font Asset
 * Name:         HelveticaNeueLTStdRoman
 * Height:       18
 * Baseline:     26
 * Style:        Antialias
 * Glyph Count:  95
 * Range Count:  3
 * Glyph Ranges: 0x20-0x7E
***********************************/
extern leRasterFont HelveticaNeueLTStdRoman;

/*****************************************************************************
 * Legato String Table
 * Encoding        ASCII
 * Language Count: 1
 * String Count:   21
 *****************************************************************************/

// language IDs
#define language_Default    0

// string IDs
#define stringID_s30_0    0
#define stringID_s29_8    1
#define stringID_s30_3    2
#define stringID_s28_6    3
#define stringID_s28_9    4
#define stringID_s28_7    5
#define stringID_s29_1    6
#define stringID_s28_5    7
#define stringID_s29_5    8
#define stringID_s29_7    9
#define stringID_s29_0    10
#define stringID_s30_1    11
#define stringID_s29_4    12
#define stringID_s29_6    13
#define stringID_s29_9    14
#define stringID_s30_4    15
#define stringID_s28_8    16
#define stringID_s30_2    17
#define stringID_s29_3    18
#define stringID_s30_5    19
#define stringID_s29_2    20

extern const leStringTable stringTable;


// string list
extern leTableString string_s30_0;
extern leTableString string_s29_8;
extern leTableString string_s30_3;
extern leTableString string_s28_6;
extern leTableString string_s28_9;
extern leTableString string_s28_7;
extern leTableString string_s29_1;
extern leTableString string_s28_5;
extern leTableString string_s29_5;
extern leTableString string_s29_7;
extern leTableString string_s29_0;
extern leTableString string_s30_1;
extern leTableString string_s29_4;
extern leTableString string_s29_6;
extern leTableString string_s29_9;
extern leTableString string_s30_4;
extern leTableString string_s28_8;
extern leTableString string_s30_2;
extern leTableString string_s29_3;
extern leTableString string_s30_5;
extern leTableString string_s29_2;

void initializeStrings(void);
//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif /* LE_GEN_ASSETS_H */
