#ifndef LE_GEN_SCREEN_DOUBLECIRC_H
#define LE_GEN_SCREEN_DOUBLECIRC_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen member widget declarations
extern leWidget* doublecirc_Panel_0;
extern leCircleWidget* doublecirc_CircleWidget0;
extern leCircleWidget* doublecirc_CircleWidget1;
extern leCircleWidget* doublecirc_CircleWidget2;

// screen lifecycle functions
// DO NOT CALL THESE DIRECTLY
leResult screenInit_doublecirc(void); // called when Legato is initialized
leResult screenShow_doublecirc(void); // called when screen is shown
void screenHide_doublecirc(void); // called when screen is hidden
void screenDestroy_doublecirc(void); // called when Legato is destroyed
void screenUpdate_doublecirc(void); // called when Legato is updating

leWidget* screenGetRoot_doublecirc(uint32_t lyrIdx); // gets a root widget for this screen

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LE_GEN_SCREEN_DOUBLECIRC_H
