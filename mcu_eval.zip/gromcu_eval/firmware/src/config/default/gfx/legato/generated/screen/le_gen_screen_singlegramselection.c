#include "gfx/legato/generated/screen/le_gen_screen_singlegramselection.h"

// screen member widget declarations
static leWidget* root0;

leWidget* singlegramselection_Panel_0;
leListWheelWidget* singlegramselection_ListWheelWidget_0;
leCircleWidget* singlegramselection_CircleWidget0;
leLabelWidget* singlegramselection_LabelWidget0;
leButtonWidget* singlegramselection_singleCup;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_singlegramselection(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_singlegramselection(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 320, 240);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    singlegramselection_Panel_0 = leWidget_New();
    singlegramselection_Panel_0->fn->setPosition(singlegramselection_Panel_0, 0, 0);
    singlegramselection_Panel_0->fn->setSize(singlegramselection_Panel_0, 320, 240);
    singlegramselection_Panel_0->fn->setScheme(singlegramselection_Panel_0, &grnbch);
    root0->fn->addChild(root0, (leWidget*)singlegramselection_Panel_0);

    singlegramselection_ListWheelWidget_0 = leListWheelWidget_New();
    singlegramselection_ListWheelWidget_0->fn->setPosition(singlegramselection_ListWheelWidget_0, 195, 8);
    singlegramselection_ListWheelWidget_0->fn->setSize(singlegramselection_ListWheelWidget_0, 80, 228);
    singlegramselection_ListWheelWidget_0->fn->setScheme(singlegramselection_ListWheelWidget_0, &listwheel_gram);
    singlegramselection_ListWheelWidget_0->fn->setBackgroundType(singlegramselection_ListWheelWidget_0, LE_WIDGET_BACKGROUND_NONE);
    singlegramselection_ListWheelWidget_0->fn->setBorderType(singlegramselection_ListWheelWidget_0, LE_WIDGET_BORDER_NONE);
    singlegramselection_ListWheelWidget_0->fn->setShowIndicators(singlegramselection_ListWheelWidget_0, LE_FALSE);
    singlegramselection_ListWheelWidget_0->fn->setShaded(singlegramselection_ListWheelWidget_0, LE_FALSE);
    singlegramselection_ListWheelWidget_0->fn->setMaxMomentum(singlegramselection_ListWheelWidget_0, 50);
    singlegramselection_ListWheelWidget_0->fn->setMomentumFalloffRate(singlegramselection_ListWheelWidget_0, 10);
    singlegramselection_ListWheelWidget_0->fn->setAutoHideWheel(singlegramselection_ListWheelWidget_0, LE_TRUE);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 0, (leString*)&string_s28_5);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 1, (leString*)&string_s28_6);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 2, (leString*)&string_s28_7);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 3, (leString*)&string_s28_8);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 4, (leString*)&string_s28_9);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 5, (leString*)&string_s29_0);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 6, (leString*)&string_s29_1);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 7, (leString*)&string_s29_2);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 8, (leString*)&string_s29_3);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 9, (leString*)&string_s29_4);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 10, (leString*)&string_s29_5);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 11, (leString*)&string_s29_6);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 12, (leString*)&string_s29_7);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 13, (leString*)&string_s29_8);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 14, (leString*)&string_s29_9);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 15, (leString*)&string_s30_0);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 16, (leString*)&string_s30_1);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 17, (leString*)&string_s30_2);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 18, (leString*)&string_s30_3);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 19, (leString*)&string_s30_4);
    singlegramselection_ListWheelWidget_0->fn->appendItem(singlegramselection_ListWheelWidget_0);
    singlegramselection_ListWheelWidget_0->fn->setItemString(singlegramselection_ListWheelWidget_0, 20, (leString*)&string_s30_5);
    singlegramselection_ListWheelWidget_0->fn->setSelectedItemChangedEventCallback(singlegramselection_ListWheelWidget_0, event_singlegramselection_ListWheelWidget_0_OnSelectionChanged);
    root0->fn->addChild(root0, (leWidget*)singlegramselection_ListWheelWidget_0);

    singlegramselection_CircleWidget0 = leCircleWidget_New();
    singlegramselection_CircleWidget0->fn->setPosition(singlegramselection_CircleWidget0, 15, 95);
    singlegramselection_CircleWidget0->fn->setSize(singlegramselection_CircleWidget0, 48, 48);
    singlegramselection_CircleWidget0->fn->setEnabled(singlegramselection_CircleWidget0, LE_FALSE);
    singlegramselection_CircleWidget0->fn->setRadius(singlegramselection_CircleWidget0, 21);
    singlegramselection_CircleWidget0->fn->setFilled(singlegramselection_CircleWidget0, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)singlegramselection_CircleWidget0);

    singlegramselection_LabelWidget0 = leLabelWidget_New();
    singlegramselection_LabelWidget0->fn->setPosition(singlegramselection_LabelWidget0, 280, 105);
    singlegramselection_LabelWidget0->fn->setSize(singlegramselection_LabelWidget0, 24, 44);
    singlegramselection_LabelWidget0->fn->setScheme(singlegramselection_LabelWidget0, &grnbch);
    singlegramselection_LabelWidget0->fn->setBackgroundType(singlegramselection_LabelWidget0, LE_WIDGET_BACKGROUND_NONE);
    singlegramselection_LabelWidget0->fn->setString(singlegramselection_LabelWidget0, (leString*)&string_unit_g);
    root0->fn->addChild(root0, (leWidget*)singlegramselection_LabelWidget0);

    singlegramselection_singleCup = leButtonWidget_New();
    singlegramselection_singleCup->fn->setPosition(singlegramselection_singleCup, 5, 76);
    singlegramselection_singleCup->fn->setSize(singlegramselection_singleCup, 128, 90);
    singlegramselection_singleCup->fn->setScheme(singlegramselection_singleCup, &listwheel_gram);
    singlegramselection_singleCup->fn->setBackgroundType(singlegramselection_singleCup, LE_WIDGET_BACKGROUND_NONE);
    singlegramselection_singleCup->fn->setBorderType(singlegramselection_singleCup, LE_WIDGET_BORDER_NONE);
    singlegramselection_singleCup->fn->setPressedOffset(singlegramselection_singleCup, 0);
    singlegramselection_singleCup->fn->setPressedEventCallback(singlegramselection_singleCup, event_singlegramselection_singleCup_OnPressed);
    singlegramselection_singleCup->fn->setReleasedEventCallback(singlegramselection_singleCup, event_singlegramselection_singleCup_OnReleased);
    root0->fn->addChild(root0, (leWidget*)singlegramselection_singleCup);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);
    leSetLayerRenderHorizontal(0, LE_TRUE);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_singlegramselection(void)
{
    root0->fn->setSize(root0, root0->parent->rect.width, root0->parent->rect.height);
}

void screenHide_singlegramselection(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    singlegramselection_Panel_0 = NULL;
    singlegramselection_ListWheelWidget_0 = NULL;
    singlegramselection_CircleWidget0 = NULL;
    singlegramselection_LabelWidget0 = NULL;
    singlegramselection_singleCup = NULL;


    showing = LE_FALSE;
}

void screenDestroy_singlegramselection(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_singlegramselection(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

