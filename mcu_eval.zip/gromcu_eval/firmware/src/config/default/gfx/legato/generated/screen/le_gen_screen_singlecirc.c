#include "gfx/legato/generated/screen/le_gen_screen_singlecirc.h"

// screen member widget declarations
static leWidget* root0;

leWidget* singlecirc_Panel_0;
leCircleWidget* singlecirc_CircleWidget0;
leCircleWidget* singlecirc_CircleWidget1;
leCircleWidget* singlecirc_CircleWidget2;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_singlecirc(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_singlecirc(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 320, 240);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    singlecirc_Panel_0 = leWidget_New();
    singlecirc_Panel_0->fn->setPosition(singlecirc_Panel_0, 0, 0);
    singlecirc_Panel_0->fn->setSize(singlecirc_Panel_0, 320, 240);
    singlecirc_Panel_0->fn->setScheme(singlecirc_Panel_0, &mydefault);
    root0->fn->addChild(root0, (leWidget*)singlecirc_Panel_0);

    singlecirc_CircleWidget0 = leCircleWidget_New();
    singlecirc_CircleWidget0->fn->setPosition(singlecirc_CircleWidget0, 15, 95);
    singlecirc_CircleWidget0->fn->setSize(singlecirc_CircleWidget0, 48, 48);
    singlecirc_CircleWidget0->fn->setEnabled(singlecirc_CircleWidget0, LE_FALSE);
    singlecirc_CircleWidget0->fn->setRadius(singlecirc_CircleWidget0, 21);
    singlecirc_CircleWidget0->fn->setFilled(singlecirc_CircleWidget0, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)singlecirc_CircleWidget0);

    singlecirc_CircleWidget1 = leCircleWidget_New();
    singlecirc_CircleWidget1->fn->setPosition(singlecirc_CircleWidget1, 152, 10);
    singlecirc_CircleWidget1->fn->setSize(singlecirc_CircleWidget1, 16, 16);
    singlecirc_CircleWidget1->fn->setMargins(singlecirc_CircleWidget1, 0, 0, 0, 0);
    singlecirc_CircleWidget1->fn->setRadius(singlecirc_CircleWidget1, 4);
    singlecirc_CircleWidget1->fn->setFilled(singlecirc_CircleWidget1, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)singlecirc_CircleWidget1);

    singlecirc_CircleWidget2 = leCircleWidget_New();
    singlecirc_CircleWidget2->fn->setPosition(singlecirc_CircleWidget2, 168, 10);
    singlecirc_CircleWidget2->fn->setSize(singlecirc_CircleWidget2, 16, 16);
    singlecirc_CircleWidget2->fn->setMargins(singlecirc_CircleWidget2, 0, 0, 0, 0);
    singlecirc_CircleWidget2->fn->setRadius(singlecirc_CircleWidget2, 4);
    singlecirc_CircleWidget2->fn->setFilled(singlecirc_CircleWidget2, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)singlecirc_CircleWidget2);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);
    leSetLayerRenderHorizontal(0, LE_TRUE);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_singlecirc(void)
{
    root0->fn->setSize(root0, root0->parent->rect.width, root0->parent->rect.height);
}

void screenHide_singlecirc(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    singlecirc_Panel_0 = NULL;
    singlecirc_CircleWidget0 = NULL;
    singlecirc_CircleWidget1 = NULL;
    singlecirc_CircleWidget2 = NULL;


    showing = LE_FALSE;
}

void screenDestroy_singlecirc(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_singlecirc(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

