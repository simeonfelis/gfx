#include "gfx/legato/generated/screen/le_gen_screen_boot.h"

// screen member widget declarations
static leWidget* root0;

leWidget* boot_Panel_0;
leImageWidget* boot_ImageWidget_0;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_boot(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_boot(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 320, 240);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    boot_Panel_0 = leWidget_New();
    boot_Panel_0->fn->setPosition(boot_Panel_0, 0, 0);
    boot_Panel_0->fn->setSize(boot_Panel_0, 320, 240);
    boot_Panel_0->fn->setScheme(boot_Panel_0, &grnbch);
    root0->fn->addChild(root0, (leWidget*)boot_Panel_0);

    boot_ImageWidget_0 = leImageWidget_New();
    boot_ImageWidget_0->fn->setPosition(boot_ImageWidget_0, 111, 70);
    boot_ImageWidget_0->fn->setBorderType(boot_ImageWidget_0, LE_WIDGET_BORDER_NONE);
    boot_ImageWidget_0->fn->setImage(boot_ImageWidget_0, (leImage*)&Image0);
    root0->fn->addChild(root0, (leWidget*)boot_ImageWidget_0);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_boot(void)
{
    root0->fn->setSize(root0, root0->rect.width, root0->rect.height);
}

void screenHide_boot(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    boot_Panel_0 = NULL;
    boot_ImageWidget_0 = NULL;


    showing = LE_FALSE;
}

void screenDestroy_boot(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_boot(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

