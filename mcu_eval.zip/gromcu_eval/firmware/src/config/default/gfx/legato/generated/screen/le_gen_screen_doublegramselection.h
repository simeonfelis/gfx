#ifndef LE_GEN_SCREEN_DOUBLEGRAMSELECTION_H
#define LE_GEN_SCREEN_DOUBLEGRAMSELECTION_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen member widget declarations
extern leWidget* doublegramselection_Panel_0;
extern leListWheelWidget* doublegramselection_ListWheelWidget_0;
extern leCircleWidget* doublegramselection_CircleWidget0;
extern leCircleWidget* doublegramselection_CircleWidget1;
extern leLabelWidget* doublegramselection_LabelWidget0;
extern leButtonWidget* doublegramselection_doubleCup;

// event handlers
// !!THESE MUST BE IMPLEMENTED IN THE APPLICATION CODE!!
void event_doublegramselection_ListWheelWidget_0_OnSelectionChanged(leListWheelWidget* wgt, int32_t idx);
void event_doublegramselection_doubleCup_OnPressed(leButtonWidget* btn);
void event_doublegramselection_doubleCup_OnReleased(leButtonWidget* btn);

// screen lifecycle functions
// DO NOT CALL THESE DIRECTLY
leResult screenInit_doublegramselection(void); // called when Legato is initialized
leResult screenShow_doublegramselection(void); // called when screen is shown
void screenHide_doublegramselection(void); // called when screen is hidden
void screenDestroy_doublegramselection(void); // called when Legato is destroyed
void screenUpdate_doublegramselection(void); // called when Legato is updating

leWidget* screenGetRoot_doublegramselection(uint32_t lyrIdx); // gets a root widget for this screen

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LE_GEN_SCREEN_DOUBLEGRAMSELECTION_H
