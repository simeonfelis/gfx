#ifndef LE_GEN_SCREEN_SINGLEGRAMSELECTION_H
#define LE_GEN_SCREEN_SINGLEGRAMSELECTION_H

#include "gfx/legato/legato.h"

#include "gfx/legato/generated/le_gen_scheme.h"
#include "gfx/legato/generated/le_gen_assets.h"

// DOM-IGNORE-BEGIN
#ifdef __cplusplus  // Provide C++ Compatibility
extern "C" {
#endif
// DOM-IGNORE-END

// screen member widget declarations
extern leWidget* singlegramselection_Panel_0;
extern leListWheelWidget* singlegramselection_ListWheelWidget_0;
extern leCircleWidget* singlegramselection_CircleWidget0;
extern leLabelWidget* singlegramselection_LabelWidget0;
extern leButtonWidget* singlegramselection_singleCup;

// event handlers
// !!THESE MUST BE IMPLEMENTED IN THE APPLICATION CODE!!
void event_singlegramselection_ListWheelWidget_0_OnSelectionChanged(leListWheelWidget* wgt, int32_t idx);
void event_singlegramselection_singleCup_OnPressed(leButtonWidget* btn);
void event_singlegramselection_singleCup_OnReleased(leButtonWidget* btn);

// screen lifecycle functions
// DO NOT CALL THESE DIRECTLY
leResult screenInit_singlegramselection(void); // called when Legato is initialized
leResult screenShow_singlegramselection(void); // called when screen is shown
void screenHide_singlegramselection(void); // called when screen is hidden
void screenDestroy_singlegramselection(void); // called when Legato is destroyed
void screenUpdate_singlegramselection(void); // called when Legato is updating

leWidget* screenGetRoot_singlegramselection(uint32_t lyrIdx); // gets a root widget for this screen

//DOM-IGNORE-BEGIN
#ifdef __cplusplus
}
#endif
//DOM-IGNORE-END

#endif // LE_GEN_SCREEN_SINGLEGRAMSELECTION_H
