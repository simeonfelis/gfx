#include "gfx/legato/generated/screen/le_gen_screen_doublegramselection.h"

// screen member widget declarations
static leWidget* root0;

leWidget* doublegramselection_Panel_0;
leListWheelWidget* doublegramselection_ListWheelWidget_0;
leCircleWidget* doublegramselection_CircleWidget0;
leCircleWidget* doublegramselection_CircleWidget1;
leLabelWidget* doublegramselection_LabelWidget0;
leButtonWidget* doublegramselection_doubleCup;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_doublegramselection(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_doublegramselection(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 320, 240);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    doublegramselection_Panel_0 = leWidget_New();
    doublegramselection_Panel_0->fn->setPosition(doublegramselection_Panel_0, 0, 0);
    doublegramselection_Panel_0->fn->setSize(doublegramselection_Panel_0, 320, 240);
    doublegramselection_Panel_0->fn->setScheme(doublegramselection_Panel_0, &grnbch);
    root0->fn->addChild(root0, (leWidget*)doublegramselection_Panel_0);

    doublegramselection_ListWheelWidget_0 = leListWheelWidget_New();
    doublegramselection_ListWheelWidget_0->fn->setPosition(doublegramselection_ListWheelWidget_0, 195, 8);
    doublegramselection_ListWheelWidget_0->fn->setSize(doublegramselection_ListWheelWidget_0, 80, 228);
    doublegramselection_ListWheelWidget_0->fn->setAlphaEnabled(doublegramselection_ListWheelWidget_0, LE_TRUE);
    doublegramselection_ListWheelWidget_0->fn->setScheme(doublegramselection_ListWheelWidget_0, &listwheel_gram);
    doublegramselection_ListWheelWidget_0->fn->setBackgroundType(doublegramselection_ListWheelWidget_0, LE_WIDGET_BACKGROUND_NONE);
    doublegramselection_ListWheelWidget_0->fn->setBorderType(doublegramselection_ListWheelWidget_0, LE_WIDGET_BORDER_NONE);
    doublegramselection_ListWheelWidget_0->fn->setShowIndicators(doublegramselection_ListWheelWidget_0, LE_FALSE);
    doublegramselection_ListWheelWidget_0->fn->setShaded(doublegramselection_ListWheelWidget_0, LE_FALSE);
    doublegramselection_ListWheelWidget_0->fn->setMaxMomentum(doublegramselection_ListWheelWidget_0, 50);
    doublegramselection_ListWheelWidget_0->fn->setMomentumFalloffRate(doublegramselection_ListWheelWidget_0, 10);
    doublegramselection_ListWheelWidget_0->fn->setAutoHideWheel(doublegramselection_ListWheelWidget_0, LE_TRUE);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 0, (leString*)&string_s28_5);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 1, (leString*)&string_s28_6);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 2, (leString*)&string_s28_7);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 3, (leString*)&string_s28_8);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 4, (leString*)&string_s28_9);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 5, (leString*)&string_s29_0);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 6, (leString*)&string_s29_1);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 7, (leString*)&string_s29_2);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 8, (leString*)&string_s29_3);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 9, (leString*)&string_s29_4);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 10, (leString*)&string_s29_5);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 11, (leString*)&string_s29_6);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 12, (leString*)&string_s29_7);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 13, (leString*)&string_s29_8);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 14, (leString*)&string_s29_9);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 15, (leString*)&string_s30_0);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 16, (leString*)&string_s30_1);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 17, (leString*)&string_s30_2);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 18, (leString*)&string_s30_3);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 19, (leString*)&string_s30_4);
    doublegramselection_ListWheelWidget_0->fn->appendItem(doublegramselection_ListWheelWidget_0);
    doublegramselection_ListWheelWidget_0->fn->setItemString(doublegramselection_ListWheelWidget_0, 20, (leString*)&string_s30_5);
    doublegramselection_ListWheelWidget_0->fn->setSelectedItemChangedEventCallback(doublegramselection_ListWheelWidget_0, event_doublegramselection_ListWheelWidget_0_OnSelectionChanged);
    root0->fn->addChild(root0, (leWidget*)doublegramselection_ListWheelWidget_0);

    doublegramselection_CircleWidget0 = leCircleWidget_New();
    doublegramselection_CircleWidget0->fn->setPosition(doublegramselection_CircleWidget0, 38, 95);
    doublegramselection_CircleWidget0->fn->setSize(doublegramselection_CircleWidget0, 48, 48);
    doublegramselection_CircleWidget0->fn->setEnabled(doublegramselection_CircleWidget0, LE_FALSE);
    doublegramselection_CircleWidget0->fn->setRadius(doublegramselection_CircleWidget0, 21);
    doublegramselection_CircleWidget0->fn->setFilled(doublegramselection_CircleWidget0, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)doublegramselection_CircleWidget0);

    doublegramselection_CircleWidget1 = leCircleWidget_New();
    doublegramselection_CircleWidget1->fn->setPosition(doublegramselection_CircleWidget1, 15, 95);
    doublegramselection_CircleWidget1->fn->setSize(doublegramselection_CircleWidget1, 48, 48);
    doublegramselection_CircleWidget1->fn->setEnabled(doublegramselection_CircleWidget1, LE_FALSE);
    doublegramselection_CircleWidget1->fn->setRadius(doublegramselection_CircleWidget1, 22);
    doublegramselection_CircleWidget1->fn->setThickness(doublegramselection_CircleWidget1, 2);
    doublegramselection_CircleWidget1->fn->setFilled(doublegramselection_CircleWidget1, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)doublegramselection_CircleWidget1);

    doublegramselection_LabelWidget0 = leLabelWidget_New();
    doublegramselection_LabelWidget0->fn->setPosition(doublegramselection_LabelWidget0, 280, 105);
    doublegramselection_LabelWidget0->fn->setSize(doublegramselection_LabelWidget0, 24, 44);
    doublegramselection_LabelWidget0->fn->setScheme(doublegramselection_LabelWidget0, &grnbch);
    doublegramselection_LabelWidget0->fn->setBackgroundType(doublegramselection_LabelWidget0, LE_WIDGET_BACKGROUND_NONE);
    doublegramselection_LabelWidget0->fn->setString(doublegramselection_LabelWidget0, (leString*)&string_unit_g);
    root0->fn->addChild(root0, (leWidget*)doublegramselection_LabelWidget0);

    doublegramselection_doubleCup = leButtonWidget_New();
    doublegramselection_doubleCup->fn->setPosition(doublegramselection_doubleCup, 6, 73);
    doublegramselection_doubleCup->fn->setSize(doublegramselection_doubleCup, 128, 90);
    doublegramselection_doubleCup->fn->setScheme(doublegramselection_doubleCup, &listwheel_gram);
    doublegramselection_doubleCup->fn->setBackgroundType(doublegramselection_doubleCup, LE_WIDGET_BACKGROUND_NONE);
    doublegramselection_doubleCup->fn->setBorderType(doublegramselection_doubleCup, LE_WIDGET_BORDER_NONE);
    doublegramselection_doubleCup->fn->setImagePosition(doublegramselection_doubleCup, LE_RELATIVE_POSITION_ABOVE);
    doublegramselection_doubleCup->fn->setPressedOffset(doublegramselection_doubleCup, 0);
    doublegramselection_doubleCup->fn->setPressedEventCallback(doublegramselection_doubleCup, event_doublegramselection_doubleCup_OnPressed);
    doublegramselection_doubleCup->fn->setReleasedEventCallback(doublegramselection_doubleCup, event_doublegramselection_doubleCup_OnReleased);
    root0->fn->addChild(root0, (leWidget*)doublegramselection_doubleCup);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_doublegramselection(void)
{
    root0->fn->setSize(root0, root0->parent->rect.width, root0->parent->rect.height);
}

void screenHide_doublegramselection(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    doublegramselection_Panel_0 = NULL;
    doublegramselection_ListWheelWidget_0 = NULL;
    doublegramselection_CircleWidget0 = NULL;
    doublegramselection_CircleWidget1 = NULL;
    doublegramselection_LabelWidget0 = NULL;
    doublegramselection_doubleCup = NULL;


    showing = LE_FALSE;
}

void screenDestroy_doublegramselection(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_doublegramselection(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

