#include "gfx/legato/generated/screen/le_gen_screen_Screen0.h"

// screen member widget declarations
static leWidget* root0;

leRectangleWidget* Screen0_RectangleWidget_0;
leRectangleWidget* Screen0_RectangleWidget_1;
leLineWidget* Screen0_LineWidget_0;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_Screen0(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_Screen0(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 320, 240);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    Screen0_RectangleWidget_0 = leRectangleWidget_New();
    Screen0_RectangleWidget_0->fn->setPosition(Screen0_RectangleWidget_0, 0, 0);
    Screen0_RectangleWidget_0->fn->setSize(Screen0_RectangleWidget_0, 320, 240);
    Screen0_RectangleWidget_0->fn->setBorderType(Screen0_RectangleWidget_0, LE_WIDGET_BORDER_LINE);
    Screen0_RectangleWidget_0->fn->setThickness(Screen0_RectangleWidget_0, 2);
    root0->fn->addChild(root0, (leWidget*)Screen0_RectangleWidget_0);

    Screen0_RectangleWidget_1 = leRectangleWidget_New();
    Screen0_RectangleWidget_1->fn->setPosition(Screen0_RectangleWidget_1, 110, 125);
    Screen0_RectangleWidget_1->fn->setBorderType(Screen0_RectangleWidget_1, LE_WIDGET_BORDER_NONE);
    Screen0_RectangleWidget_1->fn->setThickness(Screen0_RectangleWidget_1, 2);
    root0->fn->addChild(root0, (leWidget*)Screen0_RectangleWidget_1);

    Screen0_LineWidget_0 = leLineWidget_New();
    Screen0_LineWidget_0->fn->setPosition(Screen0_LineWidget_0, 107, 10);
    root0->fn->addChild(root0, (leWidget*)Screen0_LineWidget_0);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_Screen0(void)
{
    root0->fn->setSize(root0, root0->rect.width, root0->rect.height);
}

void screenHide_Screen0(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    Screen0_RectangleWidget_0 = NULL;
    Screen0_RectangleWidget_1 = NULL;
    Screen0_LineWidget_0 = NULL;


    showing = LE_FALSE;
}

void screenDestroy_Screen0(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_Screen0(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

