#include "gfx/legato/generated/screen/le_gen_screen_manual.h"

// screen member widget declarations
static leWidget* root0;

leWidget* manual_PanelWidget0;
leButtonWidget* manual_btn_start_stop;
leLabelWidget* manual_lbl_time;
leLabelWidget* manual_LabelWidget0;
leButtonWidget* manual_btn_manual;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_manual(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_manual(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 320, 240);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    manual_PanelWidget0 = leWidget_New();
    manual_PanelWidget0->fn->setPosition(manual_PanelWidget0, 0, 0);
    manual_PanelWidget0->fn->setSize(manual_PanelWidget0, 320, 240);
    manual_PanelWidget0->fn->setScheme(manual_PanelWidget0, &listwheel_gram);
    root0->fn->addChild(root0, (leWidget*)manual_PanelWidget0);

    manual_btn_start_stop = leButtonWidget_New();
    manual_btn_start_stop->fn->setPosition(manual_btn_start_stop, 25, 160);
    manual_btn_start_stop->fn->setSize(manual_btn_start_stop, 125, 60);
    manual_btn_start_stop->fn->setScheme(manual_btn_start_stop, &manual_text);
    manual_btn_start_stop->fn->setHAlignment(manual_btn_start_stop, LE_HALIGN_LEFT);
    manual_btn_start_stop->fn->setString(manual_btn_start_stop, (leString*)&string_start);
    manual_btn_start_stop->fn->setPressedEventCallback(manual_btn_start_stop, event_manual_btn_start_stop_OnPressed);
    manual_btn_start_stop->fn->setReleasedEventCallback(manual_btn_start_stop, event_manual_btn_start_stop_OnReleased);
    root0->fn->addChild(root0, (leWidget*)manual_btn_start_stop);

    manual_lbl_time = leLabelWidget_New();
    manual_lbl_time->fn->setPosition(manual_lbl_time, 187, 95);
    manual_lbl_time->fn->setSize(manual_lbl_time, 100, 54);
    manual_lbl_time->fn->setScheme(manual_lbl_time, &manual_text);
    manual_lbl_time->fn->setHAlignment(manual_lbl_time, LE_HALIGN_RIGHT);
    manual_lbl_time->fn->setString(manual_lbl_time, (leString*)&string_s5);
    root0->fn->addChild(root0, (leWidget*)manual_lbl_time);

    manual_LabelWidget0 = leLabelWidget_New();
    manual_LabelWidget0->fn->setPosition(manual_LabelWidget0, 286, 103);
    manual_LabelWidget0->fn->setSize(manual_LabelWidget0, 33, 43);
    manual_LabelWidget0->fn->setScheme(manual_LabelWidget0, &manual_text);
    manual_LabelWidget0->fn->setString(manual_LabelWidget0, (leString*)&string_unit_s);
    root0->fn->addChild(root0, (leWidget*)manual_LabelWidget0);

    manual_btn_manual = leButtonWidget_New();
    manual_btn_manual->fn->setPosition(manual_btn_manual, 25, 90);
    manual_btn_manual->fn->setSize(manual_btn_manual, 125, 60);
    manual_btn_manual->fn->setScheme(manual_btn_manual, &manual_text);
    manual_btn_manual->fn->setBorderType(manual_btn_manual, LE_WIDGET_BORDER_NONE);
    manual_btn_manual->fn->setHAlignment(manual_btn_manual, LE_HALIGN_LEFT);
    manual_btn_manual->fn->setString(manual_btn_manual, (leString*)&string_manual_M);
    manual_btn_manual->fn->setPressedOffset(manual_btn_manual, 0);
    manual_btn_manual->fn->setPressedEventCallback(manual_btn_manual, event_manual_btn_manual_OnPressed);
    manual_btn_manual->fn->setReleasedEventCallback(manual_btn_manual, event_manual_btn_manual_OnReleased);
    root0->fn->addChild(root0, (leWidget*)manual_btn_manual);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_manual(void)
{
    root0->fn->setSize(root0, root0->parent->rect.width, root0->parent->rect.height);
}

void screenHide_manual(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    manual_PanelWidget0 = NULL;
    manual_btn_start_stop = NULL;
    manual_lbl_time = NULL;
    manual_LabelWidget0 = NULL;
    manual_btn_manual = NULL;


    showing = LE_FALSE;
}

void screenDestroy_manual(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_manual(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

