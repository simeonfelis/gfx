#include "gfx/legato/generated/screen/le_gen_screen_sample.h"

// screen member widget declarations
static leWidget* root0;

leWidget* sample_Panel_0;
leListWheelWidget* sample_ListWheelWidget_0;
leCircleWidget* sample_CircleWidget_0;
leCircleWidget* sample_CircleWidget_1;
leTextFieldWidget* sample_TextFieldWidget0;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_sample(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_sample(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 240, 320);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    sample_Panel_0 = leWidget_New();
    sample_Panel_0->fn->setPosition(sample_Panel_0, 0, 0);
    sample_Panel_0->fn->setSize(sample_Panel_0, 240, 320);
    sample_Panel_0->fn->setScheme(sample_Panel_0, &grnbch);
    root0->fn->addChild(root0, (leWidget*)sample_Panel_0);

    sample_ListWheelWidget_0 = leListWheelWidget_New();
    sample_ListWheelWidget_0->fn->setPosition(sample_ListWheelWidget_0, 85, 110);
    sample_ListWheelWidget_0->fn->setSize(sample_ListWheelWidget_0, 70, 198);
    sample_ListWheelWidget_0->fn->setAlphaEnabled(sample_ListWheelWidget_0, LE_TRUE);
    sample_ListWheelWidget_0->fn->setScheme(sample_ListWheelWidget_0, &listwheel_gram);
    sample_ListWheelWidget_0->fn->setBorderType(sample_ListWheelWidget_0, LE_WIDGET_BORDER_NONE);
    sample_ListWheelWidget_0->fn->setShaded(sample_ListWheelWidget_0, LE_FALSE);
    sample_ListWheelWidget_0->fn->setMaxMomentum(sample_ListWheelWidget_0, 50);
    sample_ListWheelWidget_0->fn->setMomentumFalloffRate(sample_ListWheelWidget_0, 10);
    sample_ListWheelWidget_0->fn->setAutoHideWheel(sample_ListWheelWidget_0, LE_TRUE);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 0, (leString*)&string_s28_5);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 1, (leString*)&string_s28_6);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 2, (leString*)&string_s28_7);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 3, (leString*)&string_s28_8);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 4, (leString*)&string_s28_9);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 5, (leString*)&string_s29_0);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 6, (leString*)&string_s29_1);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 7, (leString*)&string_s29_2);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 8, (leString*)&string_s29_3);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 9, (leString*)&string_s29_4);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 10, (leString*)&string_s29_5);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 11, (leString*)&string_s29_6);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 12, (leString*)&string_s29_7);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 13, (leString*)&string_s29_8);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 14, (leString*)&string_s29_9);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 15, (leString*)&string_s30_0);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 16, (leString*)&string_s30_1);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 17, (leString*)&string_s30_2);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 18, (leString*)&string_s30_3);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 19, (leString*)&string_s30_4);
    sample_ListWheelWidget_0->fn->appendItem(sample_ListWheelWidget_0);
    sample_ListWheelWidget_0->fn->setItemString(sample_ListWheelWidget_0, 20, (leString*)&string_s30_5);
    sample_ListWheelWidget_0->fn->setSelectedItemChangedEventCallback(sample_ListWheelWidget_0, event_sample_ListWheelWidget_0_OnSelectionChanged);
    root0->fn->addChild(root0, (leWidget*)sample_ListWheelWidget_0);

    sample_CircleWidget_0 = leCircleWidget_New();
    sample_CircleWidget_0->fn->setPosition(sample_CircleWidget_0, 58, 11);
    sample_CircleWidget_0->fn->setScheme(sample_CircleWidget_0, &grnbch);
    sample_CircleWidget_0->fn->setFilled(sample_CircleWidget_0, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)sample_CircleWidget_0);

    sample_CircleWidget_1 = leCircleWidget_New();
    sample_CircleWidget_1->fn->setPosition(sample_CircleWidget_1, 87, 11);
    sample_CircleWidget_1->fn->setFilled(sample_CircleWidget_1, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)sample_CircleWidget_1);

    sample_TextFieldWidget0 = leTextFieldWidget_New();
    sample_TextFieldWidget0->fn->setPosition(sample_TextFieldWidget0, 160, 202);
    sample_TextFieldWidget0->fn->setSize(sample_TextFieldWidget0, 21, 25);
    sample_TextFieldWidget0->fn->setScheme(sample_TextFieldWidget0, &listwheel_gram);
    sample_TextFieldWidget0->fn->setBorderType(sample_TextFieldWidget0, LE_WIDGET_BORDER_NONE);
    sample_TextFieldWidget0->fn->setHAlignment(sample_TextFieldWidget0, LE_HALIGN_LEFT);
    sample_TextFieldWidget0->fn->setString(sample_TextFieldWidget0, (leString*)&string_unit_g);
    root0->fn->addChild(root0, (leWidget*)sample_TextFieldWidget0);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_sample(void)
{
    root0->fn->setSize(root0, root0->parent->rect.width, root0->parent->rect.height);
}

void screenHide_sample(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    sample_Panel_0 = NULL;
    sample_ListWheelWidget_0 = NULL;
    sample_CircleWidget_0 = NULL;
    sample_CircleWidget_1 = NULL;
    sample_TextFieldWidget0 = NULL;


    showing = LE_FALSE;
}

void screenDestroy_sample(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_sample(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

