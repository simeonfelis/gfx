#include "gfx/legato/generated/screen/le_gen_screen_doublecirc.h"

// screen member widget declarations
static leWidget* root0;

leWidget* doublecirc_Panel_0;
leCircleWidget* doublecirc_CircleWidget0;
leCircleWidget* doublecirc_CircleWidget1;
leCircleWidget* doublecirc_CircleWidget2;

static leBool initialized = LE_FALSE;
static leBool showing = LE_FALSE;

leResult screenInit_doublecirc(void)
{
    if(initialized == LE_TRUE)
        return LE_FAILURE;

    initialized = LE_TRUE;

    return LE_SUCCESS;
}

leResult screenShow_doublecirc(void)
{
    if(showing == LE_TRUE)
        return LE_FAILURE;

    // layer 0
    root0 = leWidget_New();
    root0->fn->setSize(root0, 320, 240);
    root0->fn->setBackgroundType(root0, LE_WIDGET_BACKGROUND_NONE);
    root0->fn->setMargins(root0, 0, 0, 0, 0);
    root0->flags |= LE_WIDGET_IGNOREEVENTS;
    root0->flags |= LE_WIDGET_IGNOREPICK;

    doublecirc_Panel_0 = leWidget_New();
    doublecirc_Panel_0->fn->setPosition(doublecirc_Panel_0, 0, 0);
    doublecirc_Panel_0->fn->setSize(doublecirc_Panel_0, 320, 240);
    doublecirc_Panel_0->fn->setScheme(doublecirc_Panel_0, &mydefault);
    root0->fn->addChild(root0, (leWidget*)doublecirc_Panel_0);

    doublecirc_CircleWidget0 = leCircleWidget_New();
    doublecirc_CircleWidget0->fn->setPosition(doublecirc_CircleWidget0, 38, 95);
    doublecirc_CircleWidget0->fn->setSize(doublecirc_CircleWidget0, 48, 48);
    doublecirc_CircleWidget0->fn->setEnabled(doublecirc_CircleWidget0, LE_FALSE);
    doublecirc_CircleWidget0->fn->setRadius(doublecirc_CircleWidget0, 21);
    doublecirc_CircleWidget0->fn->setFilled(doublecirc_CircleWidget0, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)doublecirc_CircleWidget0);

    doublecirc_CircleWidget1 = leCircleWidget_New();
    doublecirc_CircleWidget1->fn->setPosition(doublecirc_CircleWidget1, 15, 95);
    doublecirc_CircleWidget1->fn->setSize(doublecirc_CircleWidget1, 48, 48);
    doublecirc_CircleWidget1->fn->setEnabled(doublecirc_CircleWidget1, LE_FALSE);
    doublecirc_CircleWidget1->fn->setRadius(doublecirc_CircleWidget1, 22);
    doublecirc_CircleWidget1->fn->setThickness(doublecirc_CircleWidget1, 2);
    doublecirc_CircleWidget1->fn->setFilled(doublecirc_CircleWidget1, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)doublecirc_CircleWidget1);

    doublecirc_CircleWidget2 = leCircleWidget_New();
    doublecirc_CircleWidget2->fn->setPosition(doublecirc_CircleWidget2, 152, 10);
    doublecirc_CircleWidget2->fn->setSize(doublecirc_CircleWidget2, 16, 16);
    doublecirc_CircleWidget2->fn->setMargins(doublecirc_CircleWidget2, 0, 0, 0, 0);
    doublecirc_CircleWidget2->fn->setRadius(doublecirc_CircleWidget2, 4);
    doublecirc_CircleWidget2->fn->setFilled(doublecirc_CircleWidget2, LE_TRUE);
    root0->fn->addChild(root0, (leWidget*)doublecirc_CircleWidget2);

    leAddRootWidget(root0, 0);
    leSetLayerColorMode(0, LE_COLOR_MODE_RGB_565);

    showing = LE_TRUE;

    return LE_SUCCESS;
}

void screenUpdate_doublecirc(void)
{
    root0->fn->setSize(root0, root0->parent->rect.width, root0->parent->rect.height);
}

void screenHide_doublecirc(void)
{

    leRemoveRootWidget(root0, 0);
    leWidget_Delete(root0);
    root0 = NULL;

    doublecirc_Panel_0 = NULL;
    doublecirc_CircleWidget0 = NULL;
    doublecirc_CircleWidget1 = NULL;
    doublecirc_CircleWidget2 = NULL;


    showing = LE_FALSE;
}

void screenDestroy_doublecirc(void)
{
    if(initialized == LE_FALSE)
        return;

    initialized = LE_FALSE;
}

leWidget* screenGetRoot_doublecirc(uint32_t lyrIdx)
{
    if(lyrIdx >= LE_LAYER_COUNT)
        return NULL;

    switch(lyrIdx)
    {
        case 0:
        {
            return root0;
        }
        default:
        {
            return NULL;
        }
    }
}

